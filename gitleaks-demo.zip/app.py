# app.py
import os

# Simulated AWS secret
AWS_SECRET_KEY = "AKIAEXAMPLE1234567890"

def connect():
    print("Connecting using secret:", AWS_SECRET_KEY)
