# Gitleaks Demo

This repo is used to demonstrate Gitleaks scanning for hardcoded secrets.

⚠️ Do not use these fake secrets in real applications.
