// config.js

const apiKey = "sk_test_4eC39HqLyjWDarjtT1zdp7dc";  // Simulated Stripe secret

module.exports = {
  apiKey
};
